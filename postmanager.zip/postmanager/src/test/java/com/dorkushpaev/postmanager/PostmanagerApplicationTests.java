package com.dorkushpaev.postmanager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PostmanagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
